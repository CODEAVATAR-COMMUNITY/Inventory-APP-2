package com.example.android.ash_udacity_inventory_second_stage;

import android.app.AlertDialog;
import android.app.LoaderManager;
import android.content.ContentUris;
import android.content.CursorLoader;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.Loader;
import android.database.Cursor;
import android.net.Uri;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.example.android.ash_udacity_inventory_second_stage.data.ProductContract;

public class CatalogActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<Cursor> {
    private static final int PRODUCT_LOADER = 0;

    RelativeLayout emptyView;


    ProductCursorAdapter madapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_catalog);

        FloatingActionButton fab = findViewById(R.id.insert_book_fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CatalogActivity.this, EditorActivity.class);
                startActivity(intent);
            }
        });
        ListView ItemsListView = findViewById(R.id.list_view_item);
        emptyView = findViewById(R.id.empty_view);
        ItemsListView.setEmptyView(emptyView);

        madapter = new ProductCursorAdapter(this, null);
        ItemsListView.setAdapter(madapter);


        ItemsListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                Intent i = new Intent(CatalogActivity.this, EditorActivity.class);
                Uri currentBookUri = ContentUris.withAppendedId(ProductContract.InventoryItemEntry.CONTENT_URI, id);
                i.setData(currentBookUri);
                startActivity(i);
            }
        });
        getLoaderManager().initLoader(PRODUCT_LOADER, null, this);
    }

    private void deleteAllItems() {
        int rowsDeleted = 0;


        rowsDeleted = getContentResolver().delete(
                ProductContract.InventoryItemEntry.CONTENT_URI,
                null,
                null
        );
        if (rowsDeleted == 0) {
            Toast.makeText(this, R.string.error_while_deleting_items,
                    Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, R.string.all_items_deleted,
                    Toast.LENGTH_SHORT).show();
        }
    }

    private void showDeleteConfirmationDialog() {

        if (!(emptyView.getVisibility() == View.VISIBLE)) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage(R.string.delete_all_items);
            builder.setPositiveButton(R.string.delete, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    deleteAllItems();
                }
            });
            builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    if (dialog != null) {
                        dialog.dismiss();
                    }
                }
            });

            AlertDialog alertDialog = builder.create();
            alertDialog.show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_catalog, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_delete_all_entries:
                showDeleteConfirmationDialog();
                return true;
            default:
                return false;
        }
    }

    @Override
    public Loader<Cursor> onCreateLoader(int i, Bundle bundle) {
        String[] projection = {
                ProductContract.InventoryItemEntry._ID,
                ProductContract.InventoryItemEntry.COLUMN_PRODUCT_NAME,
                ProductContract.InventoryItemEntry.COLUMN_PRODUCT_PRICE,
                ProductContract.InventoryItemEntry.COLUMN_PRODUCT_QUANTITY,
                ProductContract.InventoryItemEntry.COLUMN_SUPPLIER_NAME,
                ProductContract.InventoryItemEntry.COLUMN_SUPPLIER_PHONE_NUMBER,
        };
        return new CursorLoader(this,
                ProductContract.InventoryItemEntry.CONTENT_URI,
                projection,
                null,
                null,
                null);
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {

        madapter.swapCursor(cursor);
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {

        madapter.swapCursor(null);

    }
}
